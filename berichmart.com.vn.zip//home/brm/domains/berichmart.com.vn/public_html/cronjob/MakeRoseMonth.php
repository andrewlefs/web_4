<?php

echo 'hello';
require_once '../index.php';
pr(Yii::app()->db);
?>
