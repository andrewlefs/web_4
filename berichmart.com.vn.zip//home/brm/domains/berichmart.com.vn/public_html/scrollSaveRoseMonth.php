<?php
header("location:http://berichmart.com.vn/member/cron/makeRoseMonth"); 
?>
